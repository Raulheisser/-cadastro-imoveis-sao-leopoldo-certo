import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";

interface ImovelFormProps {
  initialData?: any;
  pessoas: any[];
  onSubmit: (data: any) => Promise<void>;
  isLoading?: boolean;
}

export default function ImovelForm({ initialData, pessoas, onSubmit, isLoading = false }: ImovelFormProps) {
  const [formData, setFormData] = useState({
    logradouro: initialData?.logradouro || "",
    numero: initialData?.numero || "",
    bairro: initialData?.bairro || "",
    complemento: initialData?.complemento || "",
    proprietarioId: initialData?.proprietarioId?.toString() || "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.logradouro.trim()) {
      newErrors.logradouro = "Logradouro é obrigatório";
    }

    if (!formData.numero.trim()) {
      newErrors.numero = "Número é obrigatório";
    }

    if (!formData.bairro.trim()) {
      newErrors.bairro = "Bairro é obrigatório";
    }

    if (!formData.proprietarioId) {
      newErrors.proprietarioId = "Proprietário é obrigatório";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      await onSubmit({
        logradouro: formData.logradouro,
        numero: formData.numero,
        bairro: formData.bairro,
        complemento: formData.complemento || undefined,
        proprietarioId: parseInt(formData.proprietarioId),
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Logradouro */}
        <div className="md:col-span-2">
          <Label htmlFor="logradouro" className="text-slate-300">
            Logradouro *
          </Label>
          <Input
            id="logradouro"
            value={formData.logradouro}
            onChange={(e) => handleInputChange("logradouro", e.target.value)}
            placeholder="Rua, Avenida, etc."
            className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
          />
          {errors.logradouro && <p className="text-red-400 text-sm mt-1">{errors.logradouro}</p>}
        </div>

        {/* Número */}
        <div>
          <Label htmlFor="numero" className="text-slate-300">
            Número *
          </Label>
          <Input
            id="numero"
            value={formData.numero}
            onChange={(e) => handleInputChange("numero", e.target.value)}
            placeholder="123"
            className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
          />
          {errors.numero && <p className="text-red-400 text-sm mt-1">{errors.numero}</p>}
        </div>

        {/* Bairro */}
        <div>
          <Label htmlFor="bairro" className="text-slate-300">
            Bairro *
          </Label>
          <Input
            id="bairro"
            value={formData.bairro}
            onChange={(e) => handleInputChange("bairro", e.target.value)}
            placeholder="Nome do bairro"
            className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
          />
          {errors.bairro && <p className="text-red-400 text-sm mt-1">{errors.bairro}</p>}
        </div>

        {/* Complemento */}
        <div className="md:col-span-2">
          <Label htmlFor="complemento" className="text-slate-300">
            Complemento
          </Label>
          <Input
            id="complemento"
            value={formData.complemento}
            onChange={(e) => handleInputChange("complemento", e.target.value)}
            placeholder="Apartamento 404, Sala 10, etc."
            className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
          />
        </div>

        {/* Proprietário */}
        <div className="md:col-span-2">
          <Label htmlFor="proprietarioId" className="text-slate-300">
            Proprietário *
          </Label>
          <Select value={formData.proprietarioId} onValueChange={(value) => handleInputChange("proprietarioId", value)}>
            <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
              <SelectValue placeholder="Selecione um proprietário..." />
            </SelectTrigger>
            <SelectContent className="bg-slate-700 border-slate-600">
              {pessoas.length === 0 ? (
                <div className="p-2 text-slate-400 text-sm">Nenhuma pessoa cadastrada</div>
              ) : (
                pessoas.map((pessoa) => (
                  <SelectItem key={pessoa.id} value={pessoa.id.toString()}>
                    {pessoa.nome}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
          {errors.proprietarioId && <p className="text-red-400 text-sm mt-1">{errors.proprietarioId}</p>}
        </div>
      </div>

      <div className="flex gap-4 pt-4">
        <Button
          type="submit"
          disabled={isLoading || pessoas.length === 0}
          className="flex-1 bg-emerald-600 hover:bg-emerald-700"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Salvando...
            </>
          ) : (
            "Salvar"
          )}
        </Button>
      </div>

      {pessoas.length === 0 && (
        <p className="text-yellow-400 text-sm">Você precisa cadastrar pelo menos uma pessoa antes de criar um imóvel.</p>
      )}
    </form>
  );
}
