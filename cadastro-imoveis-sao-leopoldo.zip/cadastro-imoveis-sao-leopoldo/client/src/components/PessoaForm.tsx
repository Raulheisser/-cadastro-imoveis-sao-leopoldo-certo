import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";

interface PessoaFormProps {
  initialData?: any;
  onSubmit: (data: any) => Promise<void>;
  isLoading?: boolean;
}

export default function PessoaForm({ initialData, onSubmit, isLoading = false }: PessoaFormProps) {
  const [formData, setFormData] = useState({
    nome: initialData?.nome || "",
    dataNascimento: initialData?.dataNascimento
      ? new Date(initialData.dataNascimento).toISOString().split("T")[0]
      : "",
    cpf: initialData?.cpf || "",
    sexo: initialData?.sexo || "",
    telefone: initialData?.telefone || "",
    email: initialData?.email || "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.nome.trim()) {
      newErrors.nome = "Nome é obrigatório";
    }

    if (!formData.dataNascimento) {
      newErrors.dataNascimento = "Data de nascimento é obrigatória";
    }

    if (!formData.cpf.trim()) {
      newErrors.cpf = "CPF é obrigatório";
    } else if (!/^\d{3}\.\d{3}\.\d{3}-\d{2}$/.test(formData.cpf)) {
      newErrors.cpf = "CPF deve estar no formato XXX.XXX.XXX-XX";
    }

    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Email inválido";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      await onSubmit(formData);
    } catch (error) {
      console.error(error);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const formatCPF = (value: string) => {
    const cleaned = value.replace(/\D/g, "");
    if (cleaned.length <= 3) return cleaned;
    if (cleaned.length <= 6) return `${cleaned.slice(0, 3)}.${cleaned.slice(3)}`;
    if (cleaned.length <= 9) return `${cleaned.slice(0, 3)}.${cleaned.slice(3, 6)}.${cleaned.slice(6)}`;
    return `${cleaned.slice(0, 3)}.${cleaned.slice(3, 6)}.${cleaned.slice(6, 9)}-${cleaned.slice(9, 11)}`;
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Nome */}
        <div className="md:col-span-2">
          <Label htmlFor="nome" className="text-slate-300">
            Nome *
          </Label>
          <Input
            id="nome"
            value={formData.nome}
            onChange={(e) => handleInputChange("nome", e.target.value)}
            placeholder="Nome completo"
            className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
          />
          {errors.nome && <p className="text-red-400 text-sm mt-1">{errors.nome}</p>}
        </div>

        {/* Data de Nascimento */}
        <div>
          <Label htmlFor="dataNascimento" className="text-slate-300">
            Data de Nascimento *
          </Label>
          <Input
            id="dataNascimento"
            type="date"
            value={formData.dataNascimento}
            onChange={(e) => handleInputChange("dataNascimento", e.target.value)}
            className="bg-slate-700 border-slate-600 text-white"
          />
          {errors.dataNascimento && <p className="text-red-400 text-sm mt-1">{errors.dataNascimento}</p>}
        </div>

        {/* CPF */}
        <div>
          <Label htmlFor="cpf" className="text-slate-300">
            CPF *
          </Label>
          <Input
            id="cpf"
            value={formData.cpf}
            onChange={(e) => handleInputChange("cpf", formatCPF(e.target.value))}
            placeholder="000.000.000-00"
            className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
          />
          {errors.cpf && <p className="text-red-400 text-sm mt-1">{errors.cpf}</p>}
        </div>

        {/* Sexo */}
        <div>
          <Label htmlFor="sexo" className="text-slate-300">
            Sexo
          </Label>
          <Select value={formData.sexo} onValueChange={(value) => handleInputChange("sexo", value)}>
            <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
              <SelectValue placeholder="Selecione..." />
            </SelectTrigger>
            <SelectContent className="bg-slate-700 border-slate-600">
              <SelectItem value="M">Masculino</SelectItem>
              <SelectItem value="F">Feminino</SelectItem>
              <SelectItem value="O">Outro</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Telefone */}
        <div>
          <Label htmlFor="telefone" className="text-slate-300">
            Telefone
          </Label>
          <Input
            id="telefone"
            value={formData.telefone}
            onChange={(e) => handleInputChange("telefone", e.target.value)}
            placeholder="(00) 00000-0000"
            className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
          />
        </div>

        {/* Email */}
        <div>
          <Label htmlFor="email" className="text-slate-300">
            Email
          </Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => handleInputChange("email", e.target.value)}
            placeholder="email@example.com"
            className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
          />
          {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
        </div>
      </div>

      <div className="flex gap-4 pt-4">
        <Button
          type="submit"
          disabled={isLoading}
          className="flex-1 bg-blue-600 hover:bg-blue-700"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Salvando...
            </>
          ) : (
            "Salvar"
          )}
        </Button>
      </div>
    </form>
  );
}
