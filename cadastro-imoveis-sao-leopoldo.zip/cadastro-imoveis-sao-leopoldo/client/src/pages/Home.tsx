import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Users, LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p>Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="flex flex-col items-center justify-center min-h-screen px-4">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-6">
              <Building2 className="w-12 h-12 text-blue-400" />
              <h1 className="text-4xl font-bold text-white">Cadastro de Imóveis</h1>
            </div>
            <p className="text-xl text-slate-300 mb-2">Prefeitura Municipal de São Leopoldo</p>
            <p className="text-slate-400">Departamento de Desenvolvimento de Sistemas</p>
          </div>

          <Card className="w-full max-w-md bg-slate-800 border-slate-700">
            <CardHeader className="text-center">
              <CardTitle className="text-white">Bem-vindo</CardTitle>
              <CardDescription>Faça login para acessar o sistema</CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                size="lg"
              >
                Entrar no Sistema
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Building2 className="w-8 h-8 text-blue-400" />
            <div>
              <h1 className="text-xl font-bold text-white">Cadastro de Imóveis</h1>
              <p className="text-sm text-slate-400">São Leopoldo</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-slate-300">{user?.name || user?.email}</span>
            <Button
              onClick={logout}
              variant="outline"
              size="sm"
              className="border-slate-600 text-slate-300 hover:bg-slate-700"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card Pessoas */}
          <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors cursor-pointer group"
            onClick={() => setLocation("/pessoas")}>
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-900 rounded-lg group-hover:bg-blue-800 transition-colors">
                  <Users className="w-8 h-8 text-blue-400" />
                </div>
                <div>
                  <CardTitle className="text-white">Pessoas</CardTitle>
                  <CardDescription>Gerenciar cadastro de pessoas</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400 mb-4">
                Cadastre, consulte, edite e exclua registros de pessoas com validação de CPF e dados pessoais.
              </p>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                Acessar
              </Button>
            </CardContent>
          </Card>

          {/* Card Imóveis */}
          <Card className="bg-slate-800 border-slate-700 hover:border-emerald-500 transition-colors cursor-pointer group"
            onClick={() => setLocation("/imoveis")}>
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="p-3 bg-emerald-900 rounded-lg group-hover:bg-emerald-800 transition-colors">
                  <Building2 className="w-8 h-8 text-emerald-400" />
                </div>
                <div>
                  <CardTitle className="text-white">Imóveis</CardTitle>
                  <CardDescription>Gerenciar cadastro de imóveis</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-slate-400 mb-4">
                Registre imóveis com inscrição municipal automática e vincule aos proprietários cadastrados.
              </p>
              <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
                Acessar
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Info Section */}
        <div className="mt-12 bg-slate-800 rounded-lg border border-slate-700 p-6">
          <h2 className="text-xl font-bold text-white mb-4">Sobre o Sistema</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-slate-300">
            <div>
              <h3 className="font-semibold text-white mb-2">Pessoas</h3>
              <p className="text-sm">Gerencie dados de pessoas com campos obrigatórios: nome, data de nascimento e CPF.</p>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-2">Imóveis</h3>
              <p className="text-sm">Registre imóveis com inscrição municipal automática e vinculação com proprietários.</p>
            </div>
            <div>
              <h3 className="font-semibold text-white mb-2">Segurança</h3>
              <p className="text-sm">Acesso protegido com autenticação e controle de permissões para todas as operações.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
