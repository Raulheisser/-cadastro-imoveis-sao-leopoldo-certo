import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ArrowLeft, Plus, Edit2, Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import PessoaForm from "@/components/PessoaForm";

export default function Pessoas() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [openDialog, setOpenDialog] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const { data: pessoas = [], isLoading, refetch } = trpc.pessoas.list.useQuery();
  const createMutation = trpc.pessoas.create.useMutation();
  const updateMutation = trpc.pessoas.update.useMutation();
  const deleteMutation = trpc.pessoas.delete.useMutation();

  const filteredPessoas = pessoas.filter((p) =>
    p.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.cpf.includes(searchTerm)
  );

  const handleCreate = async (data: any) => {
    try {
      await createMutation.mutateAsync(data);
      toast.success("Pessoa cadastrada com sucesso!");
      setOpenDialog(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao cadastrar pessoa");
    }
  };

  const handleUpdate = async (data: any) => {
    if (!editingId) return;
    try {
      await updateMutation.mutateAsync({ id: editingId, ...data });
      toast.success("Pessoa atualizada com sucesso!");
      setEditingId(null);
      setOpenDialog(false);
      refetch();
    } catch (error) {
      toast.error("Erro ao atualizar pessoa");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteMutation.mutateAsync(id);
      toast.success("Pessoa removida com sucesso!");
      setDeleteConfirm(null);
      refetch();
    } catch (error) {
      toast.error("Erro ao remover pessoa");
    }
  };

  const editingPessoa = editingId ? pessoas.find((p) => p.id === editingId) : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/")}
              className="text-slate-300 hover:bg-slate-700"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <h1 className="text-2xl font-bold text-white">Pessoas</h1>
          </div>
          <Dialog open={openDialog} onOpenChange={setOpenDialog}>
            <DialogTrigger asChild>
              <Button
                onClick={() => setEditingId(null)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Pessoa
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-800 border-slate-700 max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-white">
                  {editingId ? "Editar Pessoa" : "Cadastrar Pessoa"}
                </DialogTitle>
                <DialogDescription>
                  Preencha os dados da pessoa. Campos marcados com * são obrigatórios.
                </DialogDescription>
              </DialogHeader>
              <PessoaForm
                initialData={editingPessoa}
                onSubmit={editingId ? handleUpdate : handleCreate}
                isLoading={createMutation.isPending || updateMutation.isPending}
              />
            </DialogContent>
          </Dialog>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search */}
        <Card className="bg-slate-800 border-slate-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Buscar Pessoas</CardTitle>
          </CardHeader>
          <CardContent>
            <Input
              placeholder="Buscar por nome ou CPF..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
            />
          </CardContent>
        </Card>

        {/* List */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">
              {filteredPessoas.length} Pessoa{filteredPessoas.length !== 1 ? "s" : ""} Cadastrada{filteredPessoas.length !== 1 ? "s" : ""}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-blue-400" />
              </div>
            ) : filteredPessoas.length === 0 ? (
              <p className="text-slate-400 text-center py-8">Nenhuma pessoa cadastrada</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-700">
                      <th className="px-4 py-3 text-left text-sm font-semibold text-slate-300">Nome</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-slate-300">CPF</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-slate-300">Data Nascimento</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-slate-300">Telefone</th>
                      <th className="px-4 py-3 text-left text-sm font-semibold text-slate-300">Ações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPessoas.map((pessoa) => (
                      <tr key={pessoa.id} className="border-b border-slate-700 hover:bg-slate-700/50">
                        <td className="px-4 py-3 text-slate-200">{pessoa.nome}</td>
                        <td className="px-4 py-3 text-slate-400">{pessoa.cpf}</td>
                        <td className="px-4 py-3 text-slate-400">
                          {new Date(pessoa.dataNascimento).toLocaleDateString("pt-BR")}
                        </td>
                        <td className="px-4 py-3 text-slate-400">{pessoa.telefone || "-"}</td>
                        <td className="px-4 py-3">
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingId(pessoa.id);
                                setOpenDialog(true);
                              }}
                              className="border-slate-600 text-slate-300 hover:bg-slate-700"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setDeleteConfirm(pessoa.id)}
                              className="border-red-600 text-red-400 hover:bg-red-900/20"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Delete Confirmation Dialog */}
        <Dialog open={deleteConfirm !== null} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
          <DialogContent className="bg-slate-800 border-slate-700">
            <DialogHeader>
              <DialogTitle className="text-white">Confirmar Exclusão</DialogTitle>
              <DialogDescription>
                Tem certeza que deseja remover esta pessoa? Esta ação não pode ser desfeita.
              </DialogDescription>
            </DialogHeader>
            <div className="flex gap-4">
              <Button
                variant="outline"
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Cancelar
              </Button>
              <Button
                onClick={() => deleteConfirm && handleDelete(deleteConfirm)}
                className="flex-1 bg-red-600 hover:bg-red-700"
                disabled={deleteMutation.isPending}
              >
                {deleteMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Removendo...
                  </>
                ) : (
                  "Remover"
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
}
