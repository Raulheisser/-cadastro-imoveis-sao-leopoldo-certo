CREATE TABLE `imoveis` (
	`id` int AUTO_INCREMENT NOT NULL,
	`inscricao_municipal` int AUTO_INCREMENT NOT NULL,
	`logradouro` varchar(255) NOT NULL,
	`numero` varchar(20) NOT NULL,
	`bairro` varchar(255) NOT NULL,
	`complemento` varchar(255),
	`proprietario_id` int NOT NULL,
	`criado_em` timestamp NOT NULL DEFAULT (now()),
	`atualizado_em` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `imoveis_id` PRIMARY KEY(`id`),
	CONSTRAINT `imoveis_inscricao_municipal_unique` UNIQUE(`inscricao_municipal`)
);
--> statement-breakpoint
CREATE TABLE `pessoas` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nome` varchar(255) NOT NULL,
	`data_nascimento` date NOT NULL,
	`cpf` varchar(14) NOT NULL,
	`sexo` varchar(1),
	`telefone` varchar(20),
	`email` varchar(320),
	`criado_em` timestamp NOT NULL DEFAULT (now()),
	`atualizado_em` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `pessoas_id` PRIMARY KEY(`id`),
	CONSTRAINT `pessoas_cpf_unique` UNIQUE(`cpf`)
);
