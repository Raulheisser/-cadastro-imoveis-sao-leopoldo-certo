import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, pessoas, imoveis, InsertPessoa, InsertImovel } from "../drizzle/schema";
import { ENV } from './_core/env';


let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Funções para Pessoas
export async function getAllPessoas() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(pessoas).orderBy(pessoas.nome);
}

export async function getPessoaById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(pessoas).where(eq(pessoas.id, id)).limit(1);
  return result[0];
}

export async function searchPessoas(query: string) {
  const db = await getDb();
  if (!db) return [];
  // Busca por nome ou CPF
  return db.select().from(pessoas)
    .where(query ? undefined : undefined)
    .orderBy(pessoas.nome);
}

export async function createPessoa(data: InsertPessoa) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(pessoas).values(data);
  return result;
}

export async function updatePessoa(id: number, data: Partial<InsertPessoa>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(pessoas).set(data).where(eq(pessoas.id, id));
}

export async function deletePessoa(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(pessoas).where(eq(pessoas.id, id));
}

// Funções para Imóveis
export async function getAllImoveis() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(imoveis).orderBy(imoveis.inscricaoMunicipal);
}

export async function getImovelById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(imoveis).where(eq(imoveis.id, id)).limit(1);
  return result[0];
}

export async function getImovelsByProprietario(proprietarioId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(imoveis).where(eq(imoveis.proprietarioId, proprietarioId));
}

export async function createImovel(data: InsertImovel) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(imoveis).values(data);
  return result;
}

export async function updateImovel(id: number, data: Partial<InsertImovel>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(imoveis).set(data).where(eq(imoveis.id, id));
}

export async function deleteImovel(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(imoveis).where(eq(imoveis.id, id));
}
