import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  getAllPessoas,
  getPessoaById,
  createPessoa,
  updatePessoa,
  deletePessoa,
  getAllImoveis,
  getImovelById,
  createImovel,
  updateImovel,
  deleteImovel,
  getImovelsByProprietario,
} from "./db";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  pessoas: router({
    list: protectedProcedure.query(async () => {
      return getAllPessoas();
    }),
    get: protectedProcedure.input(z.number()).query(async ({ input }) => {
      return getPessoaById(input);
    }),
    create: protectedProcedure
      .input(
        z.object({
          nome: z.string().min(1, "Nome é obrigatório"),
          dataNascimento: z.string(),
          cpf: z.string().min(1, "CPF é obrigatório"),
          sexo: z.string().optional(),
          telefone: z.string().optional(),
          email: z.string().email().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return createPessoa({
          nome: input.nome,
          dataNascimento: new Date(input.dataNascimento),
          cpf: input.cpf,
          sexo: input.sexo || null,
          telefone: input.telefone || null,
          email: input.email || null,
        });
      }),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          dataNascimento: z.string().optional(),
          cpf: z.string().optional(),
          sexo: z.string().optional(),
          telefone: z.string().optional(),
          email: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: any = {};
        if (data.nome) updateData.nome = data.nome;
        if (data.dataNascimento) updateData.dataNascimento = new Date(data.dataNascimento);
        if (data.cpf) updateData.cpf = data.cpf;
        if (data.sexo !== undefined) updateData.sexo = data.sexo || null;
        if (data.telefone !== undefined) updateData.telefone = data.telefone || null;
        if (data.email !== undefined) updateData.email = data.email || null;
        return updatePessoa(id, updateData);
      }),
    delete: protectedProcedure.input(z.number()).mutation(async ({ input }) => {
      return deletePessoa(input);
    }),
  }),

  imoveis: router({
    list: protectedProcedure.query(async () => {
      return getAllImoveis();
    }),
    get: protectedProcedure.input(z.number()).query(async ({ input }) => {
      return getImovelById(input);
    }),
    byProprietario: protectedProcedure.input(z.number()).query(async ({ input }) => {
      return getImovelsByProprietario(input);
    }),
    create: protectedProcedure
      .input(
        z.object({
          logradouro: z.string().min(1, "Logradouro é obrigatório"),
          numero: z.string().min(1, "Número é obrigatório"),
          bairro: z.string().min(1, "Bairro é obrigatório"),
          complemento: z.string().optional(),
          proprietarioId: z.number().min(1, "Proprietário é obrigatório"),
        })
      )
      .mutation(async ({ input }) => {
        return createImovel({
          logradouro: input.logradouro,
          numero: input.numero,
          bairro: input.bairro,
          complemento: input.complemento || null,
          proprietarioId: input.proprietarioId,
          inscricaoMunicipal: 0,
        });
      }),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          logradouro: z.string().optional(),
          numero: z.string().optional(),
          bairro: z.string().optional(),
          complemento: z.string().optional(),
          proprietarioId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return updateImovel(id, data);
      }),
    delete: protectedProcedure.input(z.number()).mutation(async ({ input }) => {
      return deleteImovel(input);
    }),
  }),
});

export type AppRouter = typeof appRouter;
