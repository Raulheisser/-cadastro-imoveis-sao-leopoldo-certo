import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createAuthContext(): TrpcContext {
  const user = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user" as const,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("imoveis router", () => {
  it("should list imoveis", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.imoveis.list();
    expect(Array.isArray(result)).toBe(true);
  });

  it("should get imovel by id", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.imoveis.get(1);
    expect(result === undefined || typeof result === "object").toBe(true);
  });

  it("should get imovel by proprietario", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.imoveis.byProprietario(1);
    expect(Array.isArray(result)).toBe(true);
  });

  it("should validate required fields on create", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.imoveis.create({
        logradouro: "",
        numero: "123",
        bairro: "Centro",
        proprietarioId: 1,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error).toBeDefined();
    }
  });

  it("should validate numero field", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.imoveis.create({
        logradouro: "Rua Teste",
        numero: "",
        bairro: "Centro",
        proprietarioId: 1,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error).toBeDefined();
    }
  });

  it("should validate bairro field", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.imoveis.create({
        logradouro: "Rua Teste",
        numero: "123",
        bairro: "",
        proprietarioId: 1,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error).toBeDefined();
    }
  });

  it("should validate proprietarioId field", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.imoveis.create({
        logradouro: "Rua Teste",
        numero: "123",
        bairro: "Centro",
        proprietarioId: 0,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error).toBeDefined();
    }
  });
});
